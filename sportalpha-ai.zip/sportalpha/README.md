# SportAlpha AI

**AI-powered sports probability intelligence.**

SportAlpha AI turns sports data into probability estimates using statistical
models, Monte Carlo simulation and an AI explanation layer. It reports
uncertainty as a first-class output.

> SportAlpha AI provides statistical and probabilistic analysis for
> informational purposes only. Predictions are not guarantees of future
> results. The platform does not sell selections, tips or guaranteed returns.

---

## Status

This repository is **step 1**: the full application shell, with a clearly
labelled demo dataset in place of a live feed and a placeholder simulation
engine behind a stable interface.

| Area | State |
|---|---|
| Landing, pricing, legal pages | Built |
| Supabase auth (register, login, reset, verify, sessions) | Built |
| Database schema + row level security | Written, not yet applied to a project |
| Dashboard, match list, match analyser | Built on demo data |
| Monte Carlo console | Built, demo engine |
| AI Analyst | Built, context-constrained |
| Stripe subscriptions | Built, test mode |
| Admin panel | Built, reads live counts |
| FastAPI service + quant engine | Built, 13 tests passing |
| Real sports feed, Dixon-Coles, xG, ML | **Step 2** |

Verified locally: `tsc --noEmit` clean, `next lint` clean, `next build`
compiles 34 routes, `pytest` 13/13, and every route returns the expected
status (public 200, private 307 to `/login`, unknown 404).

---

## Architecture

```
┌────────────────────┐        ┌─────────────────────┐
│  Next.js frontend  │──JWT──▶│  FastAPI service    │
│  App Router, RSC   │        │  quant + Monte Carlo│
└─────────┬──────────┘        └──────────┬──────────┘
          │                              │
          │  auth + RLS reads            │ service role
          ▼                              ▼
      ┌──────────────────────────────────────┐
      │        Supabase (PostgreSQL)         │
      └──────────────────────────────────────┘
          ▲
          │ webhooks
      ┌───┴────┐
      │ Stripe │
      └────────┘
```

**Why two services.** The interface needs to be fast and edge-friendly; the
quantitative work needs NumPy and CPU. Splitting them lets the frontend deploy
to Netlify and the engine scale independently on Railway, Render or Fly.io.

**Where the numbers come from.** The language model never produces a
probability. `lib/quant-context.ts` assembles every figure the analyst is
allowed to discuss, and the system prompt forbids stating anything outside it.
If a number is not in the context, the model has no business saying it.

### Layout

```
sportalpha/
├── frontend/
│   └── src/
│       ├── middleware.ts               session refresh + route guard
│       ├── app/
│       │   ├── (marketing)/            landing, pricing, 4 policy pages
│       │   ├── (auth)/                 login, register, reset, update password
│       │   ├── (app)/                  the signed-in terminal
│       │   ├── api/stripe/             checkout, portal, webhook
│       │   ├── api/ai-analyst/         analyst endpoint + limit enforcement
│       │   └── auth/                   OAuth-style callback, signout
│       ├── components/{ui,landing,app}/
│       └── lib/
│           ├── config/plans.ts         single source of truth for limits
│           ├── supabase/               browser, server and admin clients
│           ├── simulation/engine.ts    swappable simulation engine
│           ├── quant-context.ts        getQuantitativeContext(matchId)
│           ├── demo/matches.ts         labelled sample data
│           └── types/
├── backend/
│   ├── app/
│   │   ├── main.py                     FastAPI app + CORS
│   │   ├── core/                       settings, JWT verification, limits
│   │   ├── api/routes/                 health, matches, simulation, user
│   │   ├── services/                   fixtures, predictions, metering
│   │   └── database/                   service-role Supabase client
│   ├── quant_engine/
│   │   ├── base_model.py               the contract every model implements
│   │   ├── poisson_model.py            independent Poisson (Dixon-Coles hook)
│   │   ├── elo_model.py                Elo with a separate draw component
│   │   ├── ensemble.py                 weighted blend, renormalised
│   │   ├── probability_engine.py       the only entry point callers use
│   │   └── monte_carlo/monte_carlo_engine.py
│   └── tests/
└── supabase/migrations/
    ├── 0001_schema.sql
    ├── 0002_rls.sql
    └── 0003_seed_demo.sql
```

---

## Stack

**Frontend** — Next.js 14 (App Router), TypeScript in strict mode with
`noUncheckedIndexedAccess`, Tailwind CSS, lucide-react.
**Backend** — Python 3.12, FastAPI, Pydantic v2, python-jose.
**Data** — Supabase (PostgreSQL, Auth, row level security).
**Payments** — Stripe Subscriptions.

---

## Local setup

### 1. Supabase

Create a project, then run the migrations in order in the SQL editor:

```
supabase/migrations/0001_schema.sql
supabase/migrations/0002_rls.sql
supabase/migrations/0003_seed_demo.sql   # optional demo catalogue
```

In **Authentication → URL configuration**, set the Site URL to your
`NEXT_PUBLIC_SITE_URL` and add `<site>/auth/callback` to the redirect
allow-list. Enable email confirmation.

To grant yourself the admin panel, after signing up once:

```sql
update public.profiles set is_admin = true where email = 'you@example.com';
```

### 2. Frontend

```bash
cd frontend
cp .env.example .env.local        # then fill it in
npm install
npm run dev                       # http://localhost:3000
```

### 3. Backend

```bash
cd backend
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env              # then fill it in
uvicorn app.main:app --reload     # http://localhost:8000/docs
pytest                            # 13 tests
```

### 4. Stripe (test mode)

Create three recurring monthly prices — €29.90, €69.90, €149.90 — and put
their IDs in `STRIPE_PRICE_PRO`, `STRIPE_PRICE_ADVANCED`, `STRIPE_PRICE_QUANT`.
Then forward webhooks locally:

```bash
stripe listen --forward-to localhost:3000/api/stripe/webhook
```

Copy the printed `whsec_...` into `STRIPE_WEBHOOK_SECRET`. The webhook is the
only place `profiles.plan` is written — Stripe is the source of truth for
entitlement.

---

## Environment variables

Never commit a filled-in `.env`. Anything without the `NEXT_PUBLIC_` prefix is
server-only and must never reach the browser.

| Variable | Where | Purpose |
|---|---|---|
| `NEXT_PUBLIC_SUPABASE_URL` | both | Project URL |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | both | Public key, constrained by RLS |
| `SUPABASE_SERVICE_ROLE_KEY` | server | Bypasses RLS — webhook and admin only |
| `SUPABASE_JWT_SECRET` | backend | Verifies bearer tokens locally |
| `NEXT_PUBLIC_SITE_URL` | frontend | Auth redirects, Stripe return URLs |
| `NEXT_PUBLIC_API_URL` | frontend | FastAPI base URL |
| `STRIPE_SECRET_KEY` | server | `sk_test_...` in development |
| `STRIPE_WEBHOOK_SECRET` | server | Signature verification |
| `STRIPE_PRICE_{PRO,ADVANCED,QUANT}` | server | One recurring price each |
| `ANTHROPIC_API_KEY` | server | Optional; see below |
| `ALLOWED_ORIGINS` | backend | CORS allow-list |

Without `ANTHROPIC_API_KEY` the AI Analyst answers deterministically from the
same quantitative context the model would have received, so the whole flow
stays testable. The two paths can never disagree on a number, because neither
is allowed to invent one.

---

## Plan limits

`frontend/src/lib/config/plans.ts` is the single source of truth.
`backend/app/core/limits.py` mirrors it and enforces it for real — the
client-side check exists only so the interface can respond immediately.
**Keep the two files in sync.**

| | Free | Pro | Advanced | Quant |
|---|---|---|---|---|
| Price / month | €0 | €29.90 | €69.90 | €149.90 |
| Analyses / day | 3 | 30 | 100 | Unlimited |
| Monte Carlo paths | 10,000 | 50,000 | 100,000 | 500,000 |
| AI queries / day | 3 | 50 | 200 | Unlimited |
| Portfolio tools | — | — | ✓ | ✓ |
| API access | — | — | — | ✓ |

---

## Security

- **RLS is on for every table.** It is never disabled as a shortcut. `is_admin()`
  is `security definer` so the `profiles` policies can call it without recursing.
- **Two gates on private routes.** Middleware redirects anonymous requests;
  the `(app)` layout checks again before rendering, so a misconfigured matcher
  cannot leak data.
- **`usage_logs` is write-protected.** `INSERT`/`UPDATE`/`DELETE` are revoked
  from `authenticated`; the only path in is `increment_usage()`, which is
  atomic and derives the user from `auth.uid()`.
- **Service role is used in exactly two places:** the Stripe webhook (the
  caller is Stripe, not a user) and the admin metrics page (already gated
  twice).
- **No secret is ever defaulted** in either service.

---

## Deployment

**Frontend → Netlify.** `netlify.toml` sets the base directory and the Next.js
runtime plugin. Add every `NEXT_PUBLIC_*` and server variable in the Netlify
UI. Note that `next/font` fetches from Google Fonts at build time, so the build
environment needs outbound network access.

**Backend → Railway, Render or Fly.io.** A `Dockerfile` is included; the
container reads `$PORT`. Set `ALLOWED_ORIGINS` to your deployed frontend origin.

**Database → Supabase.** Run the migrations, then point the Stripe webhook at
`https://<your-site>/api/stripe/webhook`.

---

## Extending the engine (step 2)

Three seams are already isolated. Nothing above them changes.

1. **`match_service.py`** — replace `DEMO_MATCHES` with the sports-data feed.
   `list_matches`, `get_match`, `features_for` and `predict` keep their
   signatures.
2. **`getSimulationEngine()`** in `lib/simulation/engine.ts` — return an engine
   that posts to `POST /simulation` instead of simulating in the browser. The
   `SimulationEngine` interface is unchanged, so the console does not move.
3. **`quant_engine/`** — add `dixon_coles_model.py`, `xg_model.py` and an ML
   model. Subclass `BaseModel`, return a `ModelOutput`, register it in
   `probability_engine.REGISTRY`, and give it a weight in `ensemble.py`.
   Validation and normalisation are inherited, not reimplemented.

Then: value detection against market prices, a risk engine feeding the
portfolio page, and a job queue for the 500,000-path tier.

---

## Known gaps

- Demo data is used throughout the interface and is labelled as such on every
  screen that shows it.
- The four policy pages are drafting templates and **must be reviewed by a
  lawyer** before launch.
- Admin sub-sections (Users, Leagues, Models, …) are listed but not yet
  implemented — there is nothing to administer until the feed is connected.
- Churn on the admin dashboard needs 30 days of billing history.
- `monte_carlo_runs` are persisted by the FastAPI service; the browser demo
  engine does not write them, so `/history` stays empty until the Python
  engine is wired in.
