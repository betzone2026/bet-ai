import { NextResponse, type NextRequest } from 'next/server';
import type Stripe from 'stripe';
import { createAdminClient } from '@/lib/supabase/server';
import { serverEnv } from '@/lib/env';
import { PLAN_IDS, type PlanId } from '@/lib/config/plans';
import { stripe } from '../client';

export const runtime = 'nodejs';

/**
 * Stripe is the source of truth for entitlement. This handler is the only
 * place `profiles.plan` is written, and it runs with the service role
 * because the caller is Stripe, not a signed-in user.
 */
export async function POST(request: NextRequest) {
  const signature = request.headers.get('stripe-signature');
  if (!signature) {
    return NextResponse.json({ error: 'Missing signature' }, { status: 400 });
  }

  const payload = await request.text();

  let event: Stripe.Event;
  try {
    event = stripe().webhooks.constructEvent(payload, signature, serverEnv.stripeWebhookSecret);
  } catch {
    return NextResponse.json({ error: 'Invalid signature' }, { status: 400 });
  }

  const supabase = createAdminClient();

  switch (event.type) {
    case 'checkout.session.completed': {
      const session = event.data.object;
      const userId = session.metadata?.user_id ?? session.client_reference_id;
      if (userId && typeof session.subscription === 'string') {
        const subscription = await stripe().subscriptions.retrieve(session.subscription);
        await persist(supabase, userId, subscription);
      }
      break;
    }

    case 'customer.subscription.created':
    case 'customer.subscription.updated':
    case 'customer.subscription.deleted': {
      const subscription = event.data.object;
      const userId = subscription.metadata?.user_id;
      if (userId) await persist(supabase, userId, subscription);
      break;
    }

    default:
      // Everything else is acknowledged and ignored on purpose.
      break;
  }

  return NextResponse.json({ received: true });
}

type AdminClient = ReturnType<typeof createAdminClient>;

function planFromSubscription(subscription: Stripe.Subscription): PlanId {
  const candidate = subscription.metadata?.plan;
  return PLAN_IDS.includes(candidate as PlanId) ? (candidate as PlanId) : 'free';
}

async function persist(
  supabase: AdminClient,
  userId: string,
  subscription: Stripe.Subscription,
): Promise<void> {
  const active = subscription.status === 'active' || subscription.status === 'trialing';
  const plan = active ? planFromSubscription(subscription) : 'free';
  const toIso = (seconds: number | null | undefined) =>
    seconds ? new Date(seconds * 1000).toISOString() : null;

  await supabase.from('subscriptions').upsert(
    {
      user_id: userId,
      stripe_customer_id: String(subscription.customer),
      stripe_subscription_id: subscription.id,
      stripe_price_id: subscription.items.data[0]?.price.id ?? null,
      plan: planFromSubscription(subscription),
      status: subscription.status,
      current_period_start: toIso(subscription.current_period_start),
      current_period_end: toIso(subscription.current_period_end),
      cancel_at_period_end: subscription.cancel_at_period_end,
      updated_at: new Date().toISOString(),
    },
    { onConflict: 'stripe_subscription_id' },
  );

  await supabase
    .from('profiles')
    .update({ plan, subscription_status: subscription.status })
    .eq('id', userId);
}
