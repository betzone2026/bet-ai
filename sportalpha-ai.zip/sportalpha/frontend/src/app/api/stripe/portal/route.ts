import { NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase/server';
import { publicEnv, isSupabaseConfigured } from '@/lib/env';
import { stripe } from '../client';

/** Opens the Stripe billing portal for the signed-in customer. */
export async function POST() {
  if (!isSupabaseConfigured) {
    return NextResponse.json(
      { error: 'This server is not configured for authentication yet.' },
      { status: 503 },
    );
  }

  const supabase = createClient();
  const { data: userData } = await supabase.auth.getUser();
  if (!userData.user) {
    return NextResponse.json({ error: 'Log in to manage billing.' }, { status: 401 });
  }

  const { data: subscription } = await supabase
    .from('subscriptions')
    .select('stripe_customer_id')
    .eq('user_id', userData.user.id)
    .not('stripe_customer_id', 'is', null)
    .maybeSingle<{ stripe_customer_id: string }>();

  if (!subscription?.stripe_customer_id) {
    return NextResponse.json({ error: 'No billing account yet. Choose a plan first.' }, { status: 400 });
  }

  try {
    const session = await stripe().billingPortal.sessions.create({
      customer: subscription.stripe_customer_id,
      return_url: `${publicEnv.siteUrl}/subscription`,
    });
    return NextResponse.json({ url: session.url });
  } catch {
    return NextResponse.json({ error: 'The billing portal is unavailable.' }, { status: 502 });
  }
}
