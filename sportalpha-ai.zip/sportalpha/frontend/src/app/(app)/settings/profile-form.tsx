'use client';

import { useState } from 'react';
import { createClient } from '@/lib/supabase/client';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/toast';

export function ProfileForm({ initialName, email }: { initialName: string; email: string }) {
  const toast = useToast();
  const [fullName, setFullName] = useState(initialName);
  const [pending, setPending] = useState(false);

  async function handleSubmit(event: React.FormEvent) {
    event.preventDefault();
    setPending(true);

    const supabase = createClient();
    const { data: userData } = await supabase.auth.getUser();

    if (!userData.user) {
      toast.show('Your session expired. Log in again.', 'error');
      setPending(false);
      return;
    }

    const { error } = await supabase
      .from('profiles')
      .update({ full_name: fullName })
      .eq('id', userData.user.id);

    setPending(false);
    toast.show(error ? 'Changes could not be saved.' : 'Profile saved.', error ? 'error' : 'success');
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <label className="block">
        <span className="eyebrow">Email</span>
        <input
          value={email}
          readOnly
          className="mt-1.5 h-10 w-full rounded-lg border border-line bg-base/60 px-3 text-sm text-muted"
        />
        <span className="mt-1.5 block text-xs text-muted">
          Contact support to change the address on your account.
        </span>
      </label>

      <label className="block">
        <span className="eyebrow">Display name</span>
        <input
          value={fullName}
          onChange={(e) => setFullName(e.target.value)}
          className="mt-1.5 h-10 w-full rounded-lg border border-line bg-base px-3 text-sm focus:border-alpha focus:outline-none"
        />
      </label>

      <Button type="submit" disabled={pending}>
        {pending ? 'Saving…' : 'Save changes'}
      </Button>
    </form>
  );
}
