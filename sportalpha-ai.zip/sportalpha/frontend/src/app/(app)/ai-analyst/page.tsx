import type { Metadata } from 'next';
import { getProfile } from '@/lib/supabase/server';
import { PageHeader } from '@/components/app/page-header';
import { AnalystChat } from './chat';

export const metadata: Metadata = { title: 'AI Analyst' };

export default async function AiAnalystPage({
  searchParams,
}: {
  searchParams: { match?: string };
}) {
  const profile = await getProfile();

  return (
    <>
      <PageHeader
        eyebrow="Explanation layer"
        title="AI Analyst"
        description="Ask about a fixture. The analyst explains the computed figures — it never produces numbers of its own."
      />
      <AnalystChat plan={profile?.plan ?? 'free'} initialMatchId={searchParams.match} />
    </>
  );
}
