import type { Metadata } from 'next';
import { getProfile } from '@/lib/supabase/server';
import { PageHeader } from '@/components/app/page-header';
import { MonteCarloConsole } from './console';

export const metadata: Metadata = { title: 'Monte Carlo' };

export default async function MonteCarloPage({
  searchParams,
}: {
  searchParams: { match?: string };
}) {
  const profile = await getProfile();

  return (
    <>
      <PageHeader
        eyebrow="Simulation"
        title="Monte Carlo"
        description="Play a fixture out thousands of times and read the distribution that comes back."
      />
      <MonteCarloConsole plan={profile?.plan ?? 'free'} initialMatchId={searchParams.match} />
    </>
  );
}
