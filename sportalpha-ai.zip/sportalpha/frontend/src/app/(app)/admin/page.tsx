import type { Metadata } from 'next';
import { redirect } from 'next/navigation';
import { getProfile, createAdminClient } from '@/lib/supabase/server';
import { PageHeader } from '@/components/app/page-header';
import { Stat } from '@/components/ui/stat';
import { Card, CardBody, CardHeader, CardTitle } from '@/components/ui/card';
import { PLANS, type PlanId } from '@/lib/config/plans';
import type { Profile } from '@/lib/types/database';

export const metadata: Metadata = { title: 'Admin' };
export const dynamic = 'force-dynamic';

const SECTIONS = [
  'Users', 'Subscriptions', 'Sports', 'Leagues', 'Matches',
  'Models', 'Monte Carlo', 'API usage', 'System logs', 'Settings',
];

interface Metrics {
  users: number;
  activeSubscriptions: number;
  trials: number;
  mrrCents: number;
  monteCarloRuns: number;
  aiQueries: number;
  matches: number;
  recent: Profile[];
}

/**
 * Reads with the service role, which is safe here because the route is
 * already gated twice: middleware checks `is_admin`, and the page checks
 * it again before any query runs.
 */
async function loadMetrics(): Promise<Metrics | null> {
  try {
    const supabase = createAdminClient();
    const count = { count: 'exact' as const, head: true };

    const [users, subs, trials, runs, matches, byPlan, ai, recent] = await Promise.all([
      supabase.from('profiles').select('*', count),
      supabase.from('subscriptions').select('*', count).eq('status', 'active'),
      supabase.from('subscriptions').select('*', count).eq('status', 'trialing'),
      supabase.from('monte_carlo_runs').select('*', count),
      supabase.from('matches').select('*', count),
      supabase.from('profiles').select('plan').neq('plan', 'free'),
      supabase.from('usage_logs').select('usage_count').eq('feature', 'ai_query'),
      supabase.from('profiles').select('*').order('created_at', { ascending: false }).limit(8),
    ]);

    const mrrCents = ((byPlan.data ?? []) as Array<{ plan: PlanId }>).reduce(
      (sum, row) => sum + (PLANS[row.plan]?.priceCents ?? 0),
      0,
    );
    const aiQueries = ((ai.data ?? []) as Array<{ usage_count: number }>).reduce(
      (sum, row) => sum + row.usage_count,
      0,
    );

    return {
      users: users.count ?? 0,
      activeSubscriptions: subs.count ?? 0,
      trials: trials.count ?? 0,
      mrrCents,
      monteCarloRuns: runs.count ?? 0,
      aiQueries,
      matches: matches.count ?? 0,
      recent: (recent.data ?? []) as Profile[],
    };
  } catch {
    return null;
  }
}

export default async function AdminPage() {
  const profile = await getProfile();
  if (!profile?.is_admin) redirect('/dashboard');

  const metrics = await loadMetrics();

  return (
    <>
      <PageHeader
        eyebrow="Internal"
        title="Admin"
        description="Live counts read straight from the database."
      />

      {!metrics ? (
        <div className="rounded-xl border border-down/30 bg-down/[0.06] px-5 py-6">
          <p className="eyebrow text-down">Error</p>
          <h2 className="mt-1 font-display text-base font-semibold">Metrics unavailable</h2>
          <p className="mt-1 text-sm text-muted">
            The service-role key is missing or the database is unreachable. Set
            SUPABASE_SERVICE_ROLE_KEY and reload.
          </p>
        </div>
      ) : (
        <>
          <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
            <Stat label="MRR" value={`€${(metrics.mrrCents / 100).toFixed(2)}`} accent hint="Sum of active paid plans" />
            <Stat label="Users" value={metrics.users.toLocaleString('en-US')} />
            <Stat label="Active subscriptions" value={metrics.activeSubscriptions.toLocaleString('en-US')} />
            <Stat label="Trials" value={metrics.trials.toLocaleString('en-US')} />
            <Stat label="AI queries" value={metrics.aiQueries.toLocaleString('en-US')} hint="All time" />
            <Stat label="Monte Carlo runs" value={metrics.monteCarloRuns.toLocaleString('en-US')} />
            <Stat label="Matches processed" value={metrics.matches.toLocaleString('en-US')} />
            <Stat label="Churn" value="—" hint="Needs 30 days of billing history" />
          </div>

          <div className="mt-6 grid gap-5 lg:grid-cols-[1.6fr_1fr]">
            <Card>
              <CardHeader>
                <CardTitle>Recent sign-ups</CardTitle>
              </CardHeader>
              <CardBody className="p-0">
                <table className="w-full text-sm">
                  <thead className="border-b border-line">
                    <tr>
                      <th className="eyebrow px-4 py-2.5 text-left font-normal">Email</th>
                      <th className="eyebrow px-4 py-2.5 text-left font-normal">Plan</th>
                      <th className="eyebrow px-4 py-2.5 text-right font-normal">Joined</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-line">
                    {metrics.recent.map((row) => (
                      <tr key={row.id}>
                        <td className="max-w-[18ch] truncate px-4 py-2.5">{row.email}</td>
                        <td className="px-4 py-2.5 font-mono text-xs text-alpha">{row.plan}</td>
                        <td className="px-4 py-2.5 text-right font-mono text-xs text-muted">
                          {new Date(row.created_at).toLocaleDateString('en-GB')}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </CardBody>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Sections</CardTitle>
              </CardHeader>
              <CardBody>
                <ul className="grid grid-cols-2 gap-2">
                  {SECTIONS.map((section) => (
                    <li
                      key={section}
                      className="rounded-lg border border-dashed border-line px-3 py-2 text-xs text-muted"
                    >
                      {section}
                    </li>
                  ))}
                </ul>
                <p className="mt-4 text-xs leading-relaxed text-muted">
                  Each section gets its own table view once the sports-data feed is connected and
                  there is something to administer.
                </p>
              </CardBody>
            </Card>
          </div>
        </>
      )}
    </>
  );
}
