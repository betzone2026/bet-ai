/**
 * Client-side simulation engine.
 *
 * This is a placeholder that lets the Monte Carlo interface be built and
 * exercised end to end. It runs an independent-Poisson draw in the
 * browser and sits behind the `SimulationEngine` interface, so step 2 can
 * swap in an engine that posts to `POST /simulation` on the FastAPI
 * service without any change to the pages that consume it.
 */
import type { MatchView, SimulationResult } from '@/lib/types/domain';

export interface SimulationRequest {
  match: MatchView;
  simulations: number;
  /** Goals-per-match uplift applied to the home side. */
  homeAdvantage?: number;
  onProgress?: (fraction: number) => void;
  signal?: AbortSignal;
}

export interface SimulationEngine {
  readonly id: 'demo' | 'python';
  run(request: SimulationRequest): Promise<SimulationResult>;
}

/** Knuth's method: adequate for the small lambdas involved in football. */
function poisson(lambda: number): number {
  const limit = Math.exp(-lambda);
  let k = 0;
  let p = 1;
  do {
    k += 1;
    p *= Math.random();
  } while (p > limit);
  return k - 1;
}

/** Normal-approximation interval for a simulated proportion. */
function proportionInterval(p: number, n: number): [number, number] {
  const se = Math.sqrt(Math.max(p * (1 - p), 1e-9) / n);
  return [Math.max(0, p - 1.96 * se), Math.min(1, p + 1.96 * se)];
}

export const demoEngine: SimulationEngine = {
  id: 'demo',
  async run({ match, simulations, homeAdvantage = 0.15, onProgress, signal }) {
    const started = performance.now();

    // Scoring rates are derived from the stored expected goals so the
    // simulation stays consistent with the figures shown elsewhere.
    const lambdaHome = Math.max(0.15, (match.home.xgFor + match.away.xgAgainst) / 2 + homeAdvantage);
    const lambdaAway = Math.max(0.15, (match.away.xgFor + match.home.xgAgainst) / 2);

    let homeWin = 0;
    let draw = 0;
    let awayWin = 0;
    let over25 = 0;
    let btts = 0;
    const scores = new Map<string, number>();

    const chunk = 5_000;
    for (let done = 0; done < simulations; done += chunk) {
      const end = Math.min(done + chunk, simulations);
      for (let i = done; i < end; i += 1) {
        const h = poisson(lambdaHome);
        const a = poisson(lambdaAway);
        if (h > a) homeWin += 1;
        else if (h === a) draw += 1;
        else awayWin += 1;
        if (h + a > 2.5) over25 += 1;
        if (h > 0 && a > 0) btts += 1;
        const key = `${Math.min(h, 6)}-${Math.min(a, 6)}`;
        scores.set(key, (scores.get(key) ?? 0) + 1);
      }
      onProgress?.(end / simulations);
      // Yield to the event loop so progress paints and stopping works.
      await new Promise((resolve) => setTimeout(resolve, 0));
      if (signal?.aborted) throw new DOMException('Simulation stopped', 'AbortError');
    }

    const n = simulations;
    const pHome = homeWin / n;
    const pDraw = draw / n;
    const pAway = awayWin / n;

    const ranked = [...scores.entries()].sort((x, y) => y[1] - x[1]).slice(0, 12);
    const scoreDistribution: Record<string, number> = {};
    for (const [key, count] of ranked) scoreDistribution[key] = count / n;

    return {
      simulations: n,
      homeWin: pHome,
      draw: pDraw,
      awayWin: pAway,
      over25: over25 / n,
      under25: 1 - over25 / n,
      btts: btts / n,
      scoreDistribution,
      confidenceInterval: {
        home: proportionInterval(pHome, n),
        draw: proportionInterval(pDraw, n),
        away: proportionInterval(pAway, n),
      },
      executionTimeMs: Math.round(performance.now() - started),
      engine: 'demo',
    };
  },
};

/** Selects the active engine. Flips to Python once the service is live. */
export function getSimulationEngine(): SimulationEngine {
  return demoEngine;
}
