import { cookies } from 'next/headers';
import { createServerClient, type CookieOptions } from '@supabase/ssr';
import { createClient as createSupabaseClient } from '@supabase/supabase-js';
import { publicEnv, serverEnv, isSupabaseConfigured } from '@/lib/env';
import type { Profile } from '@/lib/types/database';

/** Request-scoped client that respects RLS as the signed-in user. */
export function createClient() {
  const cookieStore = cookies();
  return createServerClient(publicEnv.supabaseUrl, publicEnv.supabaseAnonKey, {
    cookies: {
      get(name: string) {
        return cookieStore.get(name)?.value;
      },
      set(name: string, value: string, options: CookieOptions) {
        try {
          cookieStore.set({ name, value, ...options });
        } catch {
          // Called from a Server Component: middleware refreshes the cookie.
        }
      },
      remove(name: string, options: CookieOptions) {
        try {
          cookieStore.set({ name, value: '', ...options });
        } catch {
          // See above.
        }
      },
    },
  });
}

/**
 * Service-role client. Bypasses RLS, so it is only ever used from route
 * handlers that have already established who the caller is — currently
 * the Stripe webhook and admin metrics.
 */
export function createAdminClient() {
  return createSupabaseClient(publicEnv.supabaseUrl, serverEnv.supabaseServiceRoleKey, {
    auth: { persistSession: false, autoRefreshToken: false },
  });
}

/**
 * Both helpers below resolve to `null` rather than throwing when the
 * project is unconfigured or the session is missing. Callers treat that
 * as "not signed in" and redirect to the login page, so a deployment
 * without credentials shows a sensible screen instead of a 500.
 */
export async function getSessionUser() {
  if (!isSupabaseConfigured) return null;
  try {
    const supabase = createClient();
    const { data, error } = await supabase.auth.getUser();
    if (error) return null;
    return data.user;
  } catch {
    return null;
  }
}

export async function getProfile(): Promise<Profile | null> {
  if (!isSupabaseConfigured) return null;

  try {
    const supabase = createClient();
    const { data: userData } = await supabase.auth.getUser();
    if (!userData.user) return null;

    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', userData.user.id)
      .maybeSingle<Profile>();

    if (error) return null;
    return data;
  } catch {
    return null;
  }
}
