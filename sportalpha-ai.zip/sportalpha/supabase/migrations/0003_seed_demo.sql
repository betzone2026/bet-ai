-- =====================================================================
-- SportAlpha AI — 0003 demo catalogue
-- Optional. Seeds a small football catalogue so the app is navigable
-- before the real sports-data feed is connected in step 2.
-- =====================================================================
insert into public.sports (name, slug) values ('Football', 'football')
  on conflict (slug) do nothing;

insert into public.leagues (sport_id, name, country, slug)
select s.id, v.name, v.country, v.slug
from public.sports s,
     (values
        ('Premier League','England','premier-league'),
        ('Serie A','Italy','serie-a'),
        ('La Liga','Spain','la-liga'),
        ('Bundesliga','Germany','bundesliga')
     ) as v(name, country, slug)
where s.slug = 'football'
on conflict (slug) do nothing;
