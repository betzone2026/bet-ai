-- =====================================================================
-- SportAlpha AI — 0002 row level security
-- Every table has RLS enabled. Nothing here is ever disabled as a
-- shortcut: if a query is blocked, add a policy, don't drop the fence.
-- =====================================================================

-- is_admin() reads the flag with definer rights so that the profiles
-- policies below can call it without recursing into their own check.
create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path = public as $$
  select coalesce((select is_admin from public.profiles where id = auth.uid()), false);
$$;

alter table public.profiles          enable row level security;
alter table public.subscriptions     enable row level security;
alter table public.sports            enable row level security;
alter table public.leagues           enable row level security;
alter table public.teams             enable row level security;
alter table public.matches           enable row level security;
alter table public.match_statistics  enable row level security;
alter table public.model_predictions enable row level security;
alter table public.monte_carlo_runs  enable row level security;
alter table public.usage_logs        enable row level security;

-- ---------- profiles --------------------------------------------------
drop policy if exists profiles_select_own on public.profiles;
create policy profiles_select_own on public.profiles
  for select to authenticated using (id = auth.uid() or public.is_admin());

drop policy if exists profiles_update_own on public.profiles;
create policy profiles_update_own on public.profiles
  for update to authenticated
  using (id = auth.uid()) with check (id = auth.uid());

-- Note: plan, subscription_status and is_admin are only ever written by
-- the service role (Stripe webhook / admin tooling), which bypasses RLS.

-- ---------- subscriptions --------------------------------------------
drop policy if exists subscriptions_select_own on public.subscriptions;
create policy subscriptions_select_own on public.subscriptions
  for select to authenticated using (user_id = auth.uid() or public.is_admin());

-- ---------- public catalogue (read-only for signed-in users) ----------
do $$
declare t text;
begin
  foreach t in array array['sports','leagues','teams','matches','match_statistics','model_predictions'] loop
    execute format('drop policy if exists %1$s_read on public.%1$s;', t);
    execute format(
      'create policy %1$s_read on public.%1$s
         for select to authenticated using (true);', t);
    execute format('drop policy if exists %1$s_admin_write on public.%1$s;', t);
    execute format(
      'create policy %1$s_admin_write on public.%1$s
         for all to authenticated
         using (public.is_admin()) with check (public.is_admin());', t);
  end loop;
end $$;

-- ---------- monte carlo runs -----------------------------------------
drop policy if exists mc_select_own on public.monte_carlo_runs;
create policy mc_select_own on public.monte_carlo_runs
  for select to authenticated using (user_id = auth.uid() or public.is_admin());

drop policy if exists mc_insert_own on public.monte_carlo_runs;
create policy mc_insert_own on public.monte_carlo_runs
  for insert to authenticated with check (user_id = auth.uid());

drop policy if exists mc_delete_own on public.monte_carlo_runs;
create policy mc_delete_own on public.monte_carlo_runs
  for delete to authenticated using (user_id = auth.uid());

-- ---------- usage logs -------------------------------------------------
drop policy if exists usage_select_own on public.usage_logs;
create policy usage_select_own on public.usage_logs
  for select to authenticated using (user_id = auth.uid() or public.is_admin());

-- Writes go exclusively through public.increment_usage().
revoke insert, update, delete on public.usage_logs from authenticated;
grant execute on function public.increment_usage(text, integer) to authenticated;
