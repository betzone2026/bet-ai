-- =====================================================================
-- SportAlpha AI — 0001 schema
-- Core domain tables. Run before 0002_rls.sql.
-- =====================================================================

create extension if not exists "pgcrypto";

-- ---------- enums ----------------------------------------------------
do $$ begin
  create type plan_tier as enum ('free', 'pro', 'advanced', 'quant');
exception when duplicate_object then null; end $$;

do $$ begin
  create type subscription_state as enum
    ('inactive','trialing','active','past_due','canceled','incomplete');
exception when duplicate_object then null; end $$;

do $$ begin
  create type match_state as enum ('scheduled','live','finished','postponed','canceled');
exception when duplicate_object then null; end $$;

-- ---------- profiles -------------------------------------------------
create table if not exists public.profiles (
  id                  uuid primary key references auth.users(id) on delete cascade,
  email               text not null,
  full_name           text,
  avatar_url          text,
  plan                plan_tier not null default 'free',
  subscription_status subscription_state not null default 'inactive',
  is_admin            boolean not null default false,
  created_at          timestamptz not null default now(),
  updated_at          timestamptz not null default now()
);

-- ---------- subscriptions -------------------------------------------
create table if not exists public.subscriptions (
  id                     uuid primary key default gen_random_uuid(),
  user_id                uuid not null references public.profiles(id) on delete cascade,
  stripe_customer_id     text,
  stripe_subscription_id text unique,
  stripe_price_id        text,
  plan                   plan_tier not null default 'free',
  status                 subscription_state not null default 'inactive',
  current_period_start   timestamptz,
  current_period_end     timestamptz,
  cancel_at_period_end   boolean not null default false,
  created_at             timestamptz not null default now(),
  updated_at             timestamptz not null default now()
);
create index if not exists subscriptions_user_idx on public.subscriptions(user_id);

-- ---------- catalogue ------------------------------------------------
create table if not exists public.sports (
  id     uuid primary key default gen_random_uuid(),
  name   text not null,
  slug   text not null unique,
  active boolean not null default true
);

create table if not exists public.leagues (
  id       uuid primary key default gen_random_uuid(),
  sport_id uuid not null references public.sports(id) on delete cascade,
  name     text not null,
  country  text,
  slug     text not null unique,
  active   boolean not null default true
);
create index if not exists leagues_sport_idx on public.leagues(sport_id);

create table if not exists public.teams (
  id          uuid primary key default gen_random_uuid(),
  league_id   uuid not null references public.leagues(id) on delete cascade,
  name        text not null,
  short_name  text,
  logo_url    text,
  external_id text,
  unique (league_id, name)
);
create index if not exists teams_league_idx on public.teams(league_id);

-- ---------- matches --------------------------------------------------
create table if not exists public.matches (
  id           uuid primary key default gen_random_uuid(),
  external_id  text unique,
  league_id    uuid not null references public.leagues(id) on delete cascade,
  home_team_id uuid not null references public.teams(id),
  away_team_id uuid not null references public.teams(id),
  match_date   timestamptz not null,
  status       match_state not null default 'scheduled',
  home_score   smallint,
  away_score   smallint,
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now(),
  constraint matches_distinct_teams check (home_team_id <> away_team_id)
);
create index if not exists matches_date_idx   on public.matches(match_date);
create index if not exists matches_league_idx on public.matches(league_id);

create table if not exists public.match_statistics (
  id         uuid primary key default gen_random_uuid(),
  match_id   uuid not null unique references public.matches(id) on delete cascade,
  home_xg    numeric(5,2),
  away_xg    numeric(5,2),
  home_form  numeric(5,2),
  away_form  numeric(5,2),
  home_elo   numeric(7,2),
  away_elo   numeric(7,2),
  raw_data   jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

-- ---------- model output ---------------------------------------------
-- Probabilities are stored as fractions in [0,1], never as percentages.
create table if not exists public.model_predictions (
  id                   uuid primary key default gen_random_uuid(),
  match_id             uuid not null references public.matches(id) on delete cascade,
  model_version        text not null,
  home_probability     numeric(6,5) not null,
  draw_probability     numeric(6,5) not null,
  away_probability     numeric(6,5) not null,
  over_15_probability  numeric(6,5),
  over_25_probability  numeric(6,5),
  over_35_probability  numeric(6,5),
  btts_probability     numeric(6,5),
  confidence_score     numeric(5,4),
  risk_score           numeric(5,4),
  created_at           timestamptz not null default now(),
  unique (match_id, model_version),
  constraint predictions_1x2_normalised check (
    abs((home_probability + draw_probability + away_probability) - 1) < 0.005
  )
);
create index if not exists predictions_match_idx on public.model_predictions(match_id);

create table if not exists public.monte_carlo_runs (
  id                uuid primary key default gen_random_uuid(),
  user_id           uuid not null references public.profiles(id) on delete cascade,
  match_id          uuid not null references public.matches(id) on delete cascade,
  simulations       integer not null check (simulations > 0),
  input_parameters  jsonb not null default '{}'::jsonb,
  results           jsonb not null default '{}'::jsonb,
  execution_time_ms integer,
  created_at        timestamptz not null default now()
);
create index if not exists mc_user_created_idx on public.monte_carlo_runs(user_id, created_at desc);

-- ---------- metering --------------------------------------------------
-- One row per user / feature / UTC day. Incremented via increment_usage().
create table if not exists public.usage_logs (
  id          uuid primary key default gen_random_uuid(),
  user_id     uuid not null references public.profiles(id) on delete cascade,
  feature     text not null,
  usage_count integer not null default 1,
  usage_date  date not null default (now() at time zone 'utc')::date,
  created_at  timestamptz not null default now(),
  unique (user_id, feature, usage_date)
);
create index if not exists usage_user_date_idx on public.usage_logs(user_id, usage_date desc);

-- ---------- triggers --------------------------------------------------
create or replace function public.touch_updated_at()
returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end $$;

do $$
declare t text;
begin
  foreach t in array array['profiles','subscriptions','matches','match_statistics'] loop
    execute format(
      'drop trigger if exists trg_touch_%1$s on public.%1$s;
       create trigger trg_touch_%1$s before update on public.%1$s
       for each row execute function public.touch_updated_at();', t);
  end loop;
end $$;

-- Create a profile automatically for every new auth user.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, email, full_name, avatar_url)
  values (
    new.id,
    new.email,
    coalesce(new.raw_user_meta_data->>'full_name', ''),
    new.raw_user_meta_data->>'avatar_url'
  )
  on conflict (id) do nothing;
  return new;
end $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- Atomic daily counter used by feature limits.
create or replace function public.increment_usage(p_feature text, p_amount integer default 1)
returns integer language plpgsql security definer set search_path = public as $$
declare v_total integer;
begin
  insert into public.usage_logs (user_id, feature, usage_count)
  values (auth.uid(), p_feature, p_amount)
  on conflict (user_id, feature, usage_date)
    do update set usage_count = public.usage_logs.usage_count + excluded.usage_count
  returning usage_count into v_total;
  return v_total;
end $$;
