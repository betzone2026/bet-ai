"""Weighted ensemble over the individual models.

Blending happens in probability space, then the result is renormalised,
so the ensemble is guaranteed to satisfy the same contract as any single
model. Weights live here rather than being scattered through callers.
"""
from __future__ import annotations

from .base_model import BaseModel, MatchFeatures, ModelOutput, normalise
from .elo_model import EloModel
from .poisson_model import PoissonModel

DEFAULT_WEIGHTS: dict[str, float] = {
    "PoissonModel": 0.65,
    "EloModel": 0.35,
}


class EnsembleModel(BaseModel):
    version = "ensemble-0.1.0"

    def __init__(
        self,
        models: list[BaseModel] | None = None,
        weights: dict[str, float] | None = None,
    ) -> None:
        self.models = models or [PoissonModel(), EloModel()]
        self.weights = weights or DEFAULT_WEIGHTS

    def _weight(self, model: BaseModel) -> float:
        return self.weights.get(model.name, 1.0 / len(self.models))

    def predict(self, features: MatchFeatures) -> ModelOutput:
        outputs = [(model, model.predict(features)) for model in self.models]
        total_weight = sum(self._weight(model) for model, _ in outputs)

        home = draw = away = 0.0
        confidence = risk = 0.0
        goals = None

        for model, output in outputs:
            w = self._weight(model) / total_weight
            home += output.probabilities.home_win * w
            draw += output.probabilities.draw * w
            away += output.probabilities.away_win * w
            confidence += output.confidence * w
            risk += output.risk * w
            # Only the scoring model produces a goals view; keep the first.
            if goals is None and output.goals is not None:
                goals = output.goals

        # Disagreement between components is itself information: when the
        # models diverge, the ensemble should report lower confidence.
        spread = max(o.probabilities.home_win for _, o in outputs) - min(
            o.probabilities.home_win for _, o in outputs
        )
        confidence = max(0.05, confidence - spread / 2)

        return ModelOutput(
            model_version=self.version,
            probabilities=normalise(home, draw, away),
            goals=goals,
            confidence=round(confidence, 4),
            risk=round(min(risk + spread / 4, 0.99), 4),
            diagnostics={
                "components": {model.name: output.as_dict() for model, output in outputs},
                "component_spread": round(spread, 4),
            },
        )
