"""Contract every probability model in SportAlpha AI implements.

A model takes match features and returns a normalised 1X2 distribution
plus, optionally, a goals-market view. Nothing downstream should ever
have to ask which model produced a result: the shape is identical.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field, asdict
from typing import Any

TOLERANCE = 1e-6


@dataclass(frozen=True)
class MatchFeatures:
    """Inputs a model is allowed to see. Extend, never bypass."""

    home_team: str
    away_team: str
    home_xg_for: float = 1.4
    home_xg_against: float = 1.2
    away_xg_for: float = 1.2
    away_xg_against: float = 1.4
    home_elo: float = 1500.0
    away_elo: float = 1500.0
    home_form: float = 0.5
    away_form: float = 0.5
    home_advantage: float = 0.15
    extra: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class Probabilities:
    """A validated 1X2 distribution. Values are fractions of 1."""

    home_win: float
    draw: float
    away_win: float

    def __post_init__(self) -> None:
        for name, value in asdict(self).items():
            if not 0.0 <= value <= 1.0:
                raise ValueError(f"{name} must lie in [0, 1], got {value}")
        total = self.home_win + self.draw + self.away_win
        if abs(total - 1.0) > 1e-3:
            raise ValueError(f"probabilities must sum to 1, got {total:.6f}")

    def as_dict(self) -> dict[str, float]:
        return {"home_win": self.home_win, "draw": self.draw, "away_win": self.away_win}


@dataclass(frozen=True)
class GoalsMarket:
    over_15: float
    over_25: float
    over_35: float
    btts: float

    def as_dict(self) -> dict[str, float]:
        return {
            "over_15": self.over_15,
            "over_25": self.over_25,
            "over_35": self.over_35,
            "btts": self.btts,
        }


@dataclass(frozen=True)
class ModelOutput:
    model_version: str
    probabilities: Probabilities
    goals: GoalsMarket | None = None
    #: 0-1. How much evidence supports the estimate, not how likely it is to win.
    confidence: float = 0.5
    #: 0-1. Dispersion of plausible outcomes; higher means less predictable.
    risk: float = 0.5
    diagnostics: dict[str, Any] = field(default_factory=dict)

    def as_dict(self) -> dict[str, Any]:
        return {
            "model_version": self.model_version,
            **self.probabilities.as_dict(),
            "goals": self.goals.as_dict() if self.goals else None,
            "confidence": self.confidence,
            "risk": self.risk,
            "diagnostics": self.diagnostics,
        }


def normalise(home: float, draw: float, away: float) -> Probabilities:
    """Clamp to non-negative and rescale so the three sum to exactly 1."""
    home, draw, away = max(home, 0.0), max(draw, 0.0), max(away, 0.0)
    total = home + draw + away
    if total <= TOLERANCE:
        raise ValueError("cannot normalise a distribution with zero mass")
    return Probabilities(home / total, draw / total, away / total)


class BaseModel(ABC):
    """Every model subclasses this and returns a ModelOutput."""

    version: str = "0.0.0"

    @property
    def name(self) -> str:
        return type(self).__name__

    @abstractmethod
    def predict(self, features: MatchFeatures) -> ModelOutput:
        """Produce a validated, normalised distribution for one fixture."""

    def __repr__(self) -> str:
        return f"<{self.name} v{self.version}>"
