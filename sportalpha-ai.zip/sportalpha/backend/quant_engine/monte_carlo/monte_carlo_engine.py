"""Monte Carlo simulation over match outcomes.

The public signature is fixed:

    run_simulation(match_data, model_probabilities, simulations)

Everything else here is an implementation detail that step 2 can replace
with a vectorised NumPy version, or with a queue-backed worker for the
500,000-path tier, without touching callers.
"""
from __future__ import annotations

import random
import time
from collections import Counter
from dataclasses import dataclass, field
from math import sqrt
from typing import Any, Mapping

MAX_SIMULATIONS = 500_000
#: Score lines above this are bucketed together in the distribution.
SCORE_CAP = 6


@dataclass
class SimulationResult:
    simulations: int
    home_win: float = 0.0
    draw: float = 0.0
    away_win: float = 0.0
    over_25: float = 0.0
    under_25: float = 0.0
    btts: float = 0.0
    score_distribution: dict[str, float] = field(default_factory=dict)
    confidence_interval: dict[str, tuple[float, float]] = field(default_factory=dict)
    execution_time_ms: int = 0
    engine: str = "python-0.1.0"

    def as_dict(self) -> dict[str, Any]:
        return {
            "simulations": self.simulations,
            "home_win": self.home_win,
            "draw": self.draw,
            "away_win": self.away_win,
            "over_25": self.over_25,
            "under_25": self.under_25,
            "btts": self.btts,
            "score_distribution": self.score_distribution,
            "confidence_interval": {k: list(v) for k, v in self.confidence_interval.items()},
            "execution_time_ms": self.execution_time_ms,
            "engine": self.engine,
        }


def _interval(p: float, n: int) -> tuple[float, float]:
    """Normal-approximation 95% interval for a simulated proportion."""
    se = sqrt(max(p * (1.0 - p), 1e-12) / n)
    return (round(max(0.0, p - 1.96 * se), 5), round(min(1.0, p + 1.96 * se), 5))


def _rates(
    match_data: Mapping[str, Any],
    model_probabilities: Mapping[str, float] | None,
) -> tuple[float, float]:
    """Derive scoring rates, preferring explicit expected goals."""
    home = float(match_data.get("home_xg", 0) or 0)
    away = float(match_data.get("away_xg", 0) or 0)

    if home > 0 and away > 0:
        return home, away

    # Fall back to a crude mapping from the 1X2 view so the engine still
    # returns something coherent when expected goals are missing.
    probabilities = model_probabilities or {}
    p_home = float(probabilities.get("home_win", 1 / 3))
    p_away = float(probabilities.get("away_win", 1 / 3))
    base = float(match_data.get("expected_total_goals", 2.6))
    total = max(p_home + p_away, 1e-6)
    return max(base * p_home / total, 0.15), max(base * p_away / total, 0.15)


def run_simulation(
    match_data: Mapping[str, Any],
    model_probabilities: Mapping[str, float] | None = None,
    simulations: int = 100_000,
    *,
    seed: int | None = None,
) -> SimulationResult:
    """Play a fixture `simulations` times and summarise the outcomes.

    Args:
        match_data: fixture features; `home_xg` and `away_xg` are used
            when present.
        model_probabilities: the engine's 1X2 view, used only as a
            fallback when expected goals are unavailable.
        simulations: number of paths, capped at MAX_SIMULATIONS.
        seed: fix for reproducible output in tests.

    Returns:
        A SimulationResult with proportions in [0, 1].
    """
    if simulations <= 0:
        raise ValueError("simulations must be positive")
    simulations = min(simulations, MAX_SIMULATIONS)

    rng = random.Random(seed)
    lam_home, lam_away = _rates(match_data, model_probabilities)

    started = time.perf_counter()

    home_wins = draws = away_wins = over_25 = btts = 0
    scores: Counter[str] = Counter()

    for _ in range(simulations):
        h = _poisson(rng, lam_home)
        a = _poisson(rng, lam_away)

        if h > a:
            home_wins += 1
        elif h == a:
            draws += 1
        else:
            away_wins += 1

        if h + a > 2:
            over_25 += 1
        if h > 0 and a > 0:
            btts += 1

        scores[f"{min(h, SCORE_CAP)}-{min(a, SCORE_CAP)}"] += 1

    n = simulations
    p_home, p_draw, p_away = home_wins / n, draws / n, away_wins / n
    p_over = over_25 / n

    return SimulationResult(
        simulations=n,
        home_win=round(p_home, 5),
        draw=round(p_draw, 5),
        away_win=round(p_away, 5),
        over_25=round(p_over, 5),
        under_25=round(1.0 - p_over, 5),
        btts=round(btts / n, 5),
        score_distribution={
            score: round(count / n, 5) for score, count in scores.most_common(12)
        },
        confidence_interval={
            "home_win": _interval(p_home, n),
            "draw": _interval(p_draw, n),
            "away_win": _interval(p_away, n),
        },
        execution_time_ms=int((time.perf_counter() - started) * 1000),
    )


def _poisson(rng: random.Random, lam: float) -> int:
    """Knuth's method. Fine for football-sized rates."""
    limit = 2.718281828459045 ** -lam
    k, p = 0, 1.0
    while True:
        k += 1
        p *= rng.random()
        if p <= limit:
            return k - 1
