"""Independent-Poisson scoring model.

Deliberately the simplest thing that produces a coherent distribution.
Step 2 replaces the independence assumption with Dixon-Coles, which
corrects the well-known underestimate of low-scoring draws; the class
below is structured so that correction slots into `_score_matrix`.
"""
from __future__ import annotations

from math import exp, factorial

from .base_model import (
    BaseModel,
    GoalsMarket,
    MatchFeatures,
    ModelOutput,
    normalise,
)

MAX_GOALS = 8


def poisson_pmf(k: int, lam: float) -> float:
    return exp(-lam) * lam**k / factorial(k)


class PoissonModel(BaseModel):
    version = "poisson-0.1.0"

    def expected_goals(self, features: MatchFeatures) -> tuple[float, float]:
        """Blend each side's attack with the opponent's defence."""
        home = (features.home_xg_for + features.away_xg_against) / 2 + features.home_advantage
        away = (features.away_xg_for + features.home_xg_against) / 2
        return max(home, 0.05), max(away, 0.05)

    def _score_matrix(self, lam_home: float, lam_away: float) -> list[list[float]]:
        """Joint distribution over score lines. Dixon-Coles hooks in here."""
        home_pmf = [poisson_pmf(k, lam_home) for k in range(MAX_GOALS + 1)]
        away_pmf = [poisson_pmf(k, lam_away) for k in range(MAX_GOALS + 1)]
        return [[h * a for a in away_pmf] for h in home_pmf]

    def predict(self, features: MatchFeatures) -> ModelOutput:
        lam_home, lam_away = self.expected_goals(features)
        matrix = self._score_matrix(lam_home, lam_away)

        home = draw = away = 0.0
        over_15 = over_25 = over_35 = btts = 0.0

        for h, row in enumerate(matrix):
            for a, p in enumerate(row):
                if h > a:
                    home += p
                elif h == a:
                    draw += p
                else:
                    away += p
                total_goals = h + a
                if total_goals > 1:
                    over_15 += p
                if total_goals > 2:
                    over_25 += p
                if total_goals > 3:
                    over_35 += p
                if h > 0 and a > 0:
                    btts += p

        probabilities = normalise(home, draw, away)

        # Confidence rises with the separation between the two rates, and
        # risk with how evenly the three outcomes are spread.
        separation = abs(lam_home - lam_away) / max(lam_home + lam_away, 1e-6)
        spread = max(probabilities.as_dict().values()) - min(probabilities.as_dict().values())

        return ModelOutput(
            model_version=self.version,
            probabilities=probabilities,
            goals=GoalsMarket(over_15, over_25, over_35, btts),
            confidence=round(min(0.5 + separation, 0.95), 4),
            risk=round(max(0.05, 1.0 - spread), 4),
            diagnostics={"lambda_home": round(lam_home, 4), "lambda_away": round(lam_away, 4)},
        )
