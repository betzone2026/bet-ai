"""Elo strength model.

Elo says nothing about goals, so the draw share is modelled separately
as a function of how close the two ratings are and then the win
probabilities are rescaled around it.
"""
from __future__ import annotations

from .base_model import BaseModel, MatchFeatures, ModelOutput, normalise

#: Rating difference at which the stronger side wins ~10x as often.
SCALE = 400.0
#: Rating points added to the home side before the comparison.
HOME_FIELD_POINTS = 60.0
#: Draw share when two sides are exactly level.
MAX_DRAW = 0.30


class EloModel(BaseModel):
    version = "elo-0.1.0"

    @staticmethod
    def expected_score(rating_a: float, rating_b: float) -> float:
        """Standard Elo expectation in [0, 1]."""
        return 1.0 / (1.0 + 10.0 ** ((rating_b - rating_a) / SCALE))

    def predict(self, features: MatchFeatures) -> ModelOutput:
        home_rating = features.home_elo + HOME_FIELD_POINTS
        away_rating = features.away_elo

        expected_home = self.expected_score(home_rating, away_rating)
        gap = abs(home_rating - away_rating)

        # Draws are commonest between evenly matched sides and fall away
        # roughly exponentially as the gap widens.
        draw = MAX_DRAW * 2.718281828 ** (-gap / 300.0)
        remaining = 1.0 - draw

        probabilities = normalise(
            expected_home * remaining,
            draw,
            (1.0 - expected_home) * remaining,
        )

        return ModelOutput(
            model_version=self.version,
            probabilities=probabilities,
            confidence=round(min(0.45 + gap / 800.0, 0.9), 4),
            risk=round(max(0.05, 1.0 - (max(probabilities.as_dict().values()) - draw)), 4),
            diagnostics={"elo_gap": round(gap, 2), "expected_home": round(expected_home, 4)},
        )

    @staticmethod
    def update(rating: float, opponent: float, score: float, k: float = 20.0) -> float:
        """Post-match rating update. `score` is 1 win / 0.5 draw / 0 loss."""
        expected = EloModel.expected_score(rating, opponent)
        return rating + k * (score - expected)
