"""SportAlpha AI quantitative engine.

Public surface:
    MatchFeatures, ModelOutput, Probabilities  - the data contract
    ProbabilityEngine                          - how callers get estimates
    run_simulation                             - Monte Carlo entry point
"""
from .base_model import (
    BaseModel,
    GoalsMarket,
    MatchFeatures,
    ModelOutput,
    Probabilities,
    normalise,
)
from .elo_model import EloModel
from .ensemble import EnsembleModel
from .poisson_model import PoissonModel
from .probability_engine import ProbabilityEngine
from .monte_carlo.monte_carlo_engine import run_simulation

__all__ = [
    "BaseModel",
    "GoalsMarket",
    "MatchFeatures",
    "ModelOutput",
    "Probabilities",
    "normalise",
    "PoissonModel",
    "EloModel",
    "EnsembleModel",
    "ProbabilityEngine",
    "run_simulation",
]
