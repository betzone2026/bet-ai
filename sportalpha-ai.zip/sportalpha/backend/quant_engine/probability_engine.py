"""The single entry point the API uses to obtain probabilities.

Callers ask the engine, never a model directly. That keeps model
selection, validation and versioning in one place, and means swapping in
a machine-learning model in step 2 changes nothing above this line.
"""
from __future__ import annotations

from dataclasses import dataclass

from .base_model import BaseModel, MatchFeatures, ModelOutput
from .elo_model import EloModel
from .ensemble import EnsembleModel
from .poisson_model import PoissonModel

REGISTRY: dict[str, type[BaseModel]] = {
    "poisson": PoissonModel,
    "elo": EloModel,
    "ensemble": EnsembleModel,
}

DEFAULT_MODEL = "ensemble"


@dataclass
class ProbabilityEngine:
    model_key: str = DEFAULT_MODEL

    def __post_init__(self) -> None:
        if self.model_key not in REGISTRY:
            raise KeyError(
                f"unknown model {self.model_key!r}; available: {sorted(REGISTRY)}"
            )
        self._model: BaseModel = REGISTRY[self.model_key]()

    @property
    def model(self) -> BaseModel:
        return self._model

    def estimate(self, features: MatchFeatures) -> ModelOutput:
        output = self._model.predict(features)
        # The dataclass validates on construction, so reaching here means
        # the distribution is already normalised and in range.
        return output

    @staticmethod
    def available_models() -> list[str]:
        return sorted(REGISTRY)
