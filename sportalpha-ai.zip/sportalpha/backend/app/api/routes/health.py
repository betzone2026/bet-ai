from fastapi import APIRouter, Depends

from app.core.config import Settings, get_settings
from app.database.supabase_client import get_supabase
from app.models.schemas import HealthResponse

router = APIRouter(tags=["system"])


@router.get("/health", response_model=HealthResponse)
async def health(settings: Settings = Depends(get_settings)) -> HealthResponse:
    return HealthResponse(
        version=settings.api_version,
        environment=settings.environment,
        database=get_supabase() is not None,
    )
