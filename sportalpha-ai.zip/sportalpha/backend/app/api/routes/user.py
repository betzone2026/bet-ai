from fastapi import APIRouter, Depends

from app.core.limits import is_unlimited, limits_for
from app.core.security import CurrentUser, get_current_user
from app.models.schemas import UsageResponse
from app.services import usage_service

router = APIRouter(tags=["user"])


@router.get("/user/usage", response_model=UsageResponse)
async def get_usage(user: CurrentUser = Depends(get_current_user)) -> UsageResponse:
    limits = limits_for(user.plan)
    return UsageResponse(
        plan=user.plan,
        usage=usage_service.usage_today(user.id),
        limits={
            "max_daily_analysis": _serialise(limits.max_daily_analysis),
            "monte_carlo_limit": limits.monte_carlo_limit,
            "ai_queries_daily": _serialise(limits.ai_queries_daily),
            "monte_carlo_runs_daily": _serialise(limits.monte_carlo_runs_daily),
            "api_access": limits.api_access,
            "portfolio_tools": limits.portfolio_tools,
        },
    )


def _serialise(value: float) -> str | int:
    """JSON has no infinity, so unlimited travels as a string."""
    return "unlimited" if is_unlimited(value) else int(value)
