from fastapi import APIRouter, Depends, HTTPException, Query, status

from app.core.security import CurrentUser, get_current_user
from app.models.schemas import MatchResponse, PredictionResponse
from app.services import match_service

router = APIRouter(tags=["matches"])


@router.get("/matches", response_model=list[MatchResponse])
async def list_matches(
    limit: int = Query(default=50, ge=1, le=200),
    _: CurrentUser = Depends(get_current_user),
) -> list[MatchResponse]:
    return [MatchResponse(**m) for m in match_service.list_matches(limit)]


@router.get("/matches/{match_id}", response_model=MatchResponse)
async def get_match(
    match_id: str,
    _: CurrentUser = Depends(get_current_user),
) -> MatchResponse:
    match = match_service.get_match(match_id)
    if match is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "That match is not in the catalogue.")
    return MatchResponse(**match)


@router.get("/predictions/{match_id}", response_model=PredictionResponse)
async def get_prediction(
    match_id: str,
    _: CurrentUser = Depends(get_current_user),
) -> PredictionResponse:
    match = match_service.get_match(match_id)
    if match is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "That match is not in the catalogue.")
    return PredictionResponse(**match_service.predict(match))
