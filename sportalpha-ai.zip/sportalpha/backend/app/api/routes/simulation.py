"""Monte Carlo endpoints.

Plan limits are enforced here rather than in the client, and the run is
persisted so the user's history survives a page reload.
"""
from __future__ import annotations

import uuid

from fastapi import APIRouter, Depends, HTTPException, status

from app.core.limits import limits_for, within_limit
from app.core.security import CurrentUser, get_current_user
from app.database.supabase_client import get_supabase
from app.models.schemas import SimulationRequest, SimulationResponse
from app.services import match_service, usage_service
from quant_engine import run_simulation

router = APIRouter(tags=["simulation"])

_RUNS: dict[str, SimulationResponse] = {}


@router.post("/simulation", response_model=SimulationResponse, status_code=status.HTTP_201_CREATED)
async def create_simulation(
    payload: SimulationRequest,
    user: CurrentUser = Depends(get_current_user),
) -> SimulationResponse:
    match = match_service.get_match(payload.match_id)
    if match is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "That match is not in the catalogue.")

    limits = limits_for(user.plan)

    if payload.simulations > limits.monte_carlo_limit:
        raise HTTPException(
            status.HTTP_402_PAYMENT_REQUIRED,
            f"The {user.plan} plan allows up to {limits.monte_carlo_limit:,} paths per run.",
        )

    used = usage_service.usage_today(user.id).get("monte_carlo", 0)
    if not within_limit(used, limits.monte_carlo_runs_daily):
        raise HTTPException(
            status.HTTP_429_TOO_MANY_REQUESTS,
            "You have used today's simulation allowance. It resets at midnight UTC.",
        )

    prediction = match_service.predict(match)
    result = run_simulation(
        match_data=match,
        model_probabilities={
            "home_win": prediction["home_probability"],
            "draw": prediction["draw_probability"],
            "away_win": prediction["away_probability"],
        },
        simulations=payload.simulations,
        seed=payload.seed,
    )

    run_id = str(uuid.uuid4())
    response = SimulationResponse(
        id=run_id,
        match_id=payload.match_id,
        **{k: v for k, v in result.as_dict().items() if k != "engine"},
        engine=result.engine,
    )

    _RUNS[run_id] = response
    usage_service.record_usage(user.id, "monte_carlo")
    _persist(run_id, user.id, payload, result)

    return response


@router.get("/simulation/{run_id}", response_model=SimulationResponse)
async def get_simulation(
    run_id: str,
    _: CurrentUser = Depends(get_current_user),
) -> SimulationResponse:
    run = _RUNS.get(run_id)
    if run is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "No simulation with that id.")
    return run


def _persist(run_id: str, user_id: str, payload: SimulationRequest, result) -> None:
    supabase = get_supabase()
    if supabase is None:
        return
    supabase.table("monte_carlo_runs").insert(
        {
            "id": run_id,
            "user_id": user_id,
            "match_id": payload.match_id,
            "simulations": result.simulations,
            "input_parameters": payload.model_dump(mode="json"),
            "results": result.as_dict(),
            "execution_time_ms": result.execution_time_ms,
        }
    ).execute()
