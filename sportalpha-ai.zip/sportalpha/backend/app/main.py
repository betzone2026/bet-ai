"""SportAlpha AI quantitative API.

Serves fixtures, model probabilities and Monte Carlo simulations to the
Next.js frontend. Authentication is delegated to Supabase: the frontend
forwards the user's access token and this service verifies it.
"""
from __future__ import annotations

import logging

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.api.routes import health, matches, simulation, user
from app.core.config import get_settings

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("sportalpha")

settings = get_settings()

app = FastAPI(
    title=settings.app_name,
    version=settings.api_version,
    description=(
        "Statistical and probabilistic analysis of sporting events. "
        "Outputs describe uncertainty and are not guarantees of future results."
    ),
    docs_url="/docs",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins,
    allow_credentials=True,
    allow_methods=["GET", "POST", "OPTIONS"],
    allow_headers=["Authorization", "Content-Type"],
)

app.include_router(health.router)
app.include_router(matches.router)
app.include_router(simulation.router)
app.include_router(user.router)


@app.on_event("startup")
async def on_startup() -> None:
    if not settings.is_configured:
        logger.warning(
            "Supabase is not configured: authenticated endpoints will refuse requests."
        )
