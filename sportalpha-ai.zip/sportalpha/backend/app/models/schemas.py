"""Request and response bodies. Probabilities are always fractions of 1."""
from __future__ import annotations

from datetime import datetime
from typing import Any, Literal

from pydantic import BaseModel, Field


class HealthResponse(BaseModel):
    status: Literal["ok"] = "ok"
    version: str
    environment: str
    database: bool = Field(description="True when Supabase credentials are present.")


class TeamRef(BaseModel):
    id: str
    name: str


class MatchResponse(BaseModel):
    id: str
    league: str
    home_team: str
    away_team: str
    match_date: datetime
    status: str
    home_score: int | None = None
    away_score: int | None = None


class PredictionResponse(BaseModel):
    match_id: str
    model_version: str
    home_probability: float = Field(ge=0, le=1)
    draw_probability: float = Field(ge=0, le=1)
    away_probability: float = Field(ge=0, le=1)
    over_15_probability: float | None = Field(default=None, ge=0, le=1)
    over_25_probability: float | None = Field(default=None, ge=0, le=1)
    over_35_probability: float | None = Field(default=None, ge=0, le=1)
    btts_probability: float | None = Field(default=None, ge=0, le=1)
    confidence_score: float = Field(ge=0, le=1)
    risk_score: float = Field(ge=0, le=1)
    generated_at: datetime


class SimulationRequest(BaseModel):
    match_id: str
    simulations: int = Field(default=100_000, gt=0, le=500_000)
    home_advantage: float = Field(default=0.15, ge=0, le=1)
    seed: int | None = None


class SimulationResponse(BaseModel):
    id: str
    match_id: str
    simulations: int
    home_win: float
    draw: float
    away_win: float
    over_25: float
    under_25: float
    btts: float
    score_distribution: dict[str, float]
    confidence_interval: dict[str, list[float]]
    execution_time_ms: int
    engine: str


class UsageResponse(BaseModel):
    plan: str
    usage: dict[str, int]
    limits: dict[str, Any]
