"""Plan limits, mirroring `frontend/src/lib/config/plans.ts`.

The two files must agree. The frontend enforces limits for a responsive
interface; this module enforces them for real, because a client-side
check is a hint, not a control.
"""
from __future__ import annotations

from dataclasses import dataclass

UNLIMITED = float("inf")


@dataclass(frozen=True)
class PlanLimits:
    max_daily_analysis: float
    monte_carlo_limit: int
    ai_queries_daily: float
    monte_carlo_runs_daily: float
    api_access: bool
    portfolio_tools: bool


PLAN_LIMITS: dict[str, PlanLimits] = {
    "free": PlanLimits(3, 10_000, 3, 5, False, False),
    "pro": PlanLimits(30, 50_000, 50, 50, False, False),
    "advanced": PlanLimits(100, 100_000, 200, 200, False, True),
    "quant": PlanLimits(UNLIMITED, 500_000, UNLIMITED, UNLIMITED, True, True),
}


def limits_for(plan: str | None) -> PlanLimits:
    return PLAN_LIMITS.get(plan or "free", PLAN_LIMITS["free"])


def is_unlimited(value: float) -> bool:
    return value == UNLIMITED


def within_limit(used: int, allowance: float) -> bool:
    return is_unlimited(allowance) or used < allowance
