"""Settings, read from the environment. No secret is ever defaulted."""
from __future__ import annotations

from functools import lru_cache

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    app_name: str = "SportAlpha AI API"
    environment: str = "development"
    api_version: str = "0.1.0"

    # Supabase
    supabase_url: str = ""
    supabase_anon_key: str = ""
    supabase_service_role_key: str = ""
    supabase_jwt_secret: str = ""

    # CORS: the frontend origins allowed to call this service.
    allowed_origins: str = "http://localhost:3000"

    @property
    def cors_origins(self) -> list[str]:
        return [origin.strip() for origin in self.allowed_origins.split(",") if origin.strip()]

    @property
    def is_configured(self) -> bool:
        return bool(self.supabase_url and self.supabase_jwt_secret)


@lru_cache
def get_settings() -> Settings:
    return Settings()
