"""Daily feature metering, backed by `public.usage_logs`."""
from __future__ import annotations

from datetime import datetime, timezone

from app.database.supabase_client import get_supabase

TRACKED_FEATURES = ("match_analysis", "ai_query", "monte_carlo")


def _today() -> str:
    return datetime.now(timezone.utc).date().isoformat()


def usage_today(user_id: str) -> dict[str, int]:
    """Counts per feature for the current UTC day. Zeroes when offline."""
    supabase = get_supabase()
    counts = {feature: 0 for feature in TRACKED_FEATURES}
    if supabase is None:
        return counts

    response = (
        supabase.table("usage_logs")
        .select("feature, usage_count")
        .eq("user_id", user_id)
        .eq("usage_date", _today())
        .execute()
    )
    for row in response.data or []:
        counts[row["feature"]] = row.get("usage_count", 0)
    return counts


def record_usage(user_id: str, feature: str, amount: int = 1) -> None:
    """Increment a counter. Silently no-ops when the database is absent."""
    supabase = get_supabase()
    if supabase is None:
        return

    existing = (
        supabase.table("usage_logs")
        .select("id, usage_count")
        .eq("user_id", user_id)
        .eq("feature", feature)
        .eq("usage_date", _today())
        .limit(1)
        .execute()
    )

    if existing.data:
        row = existing.data[0]
        supabase.table("usage_logs").update(
            {"usage_count": row["usage_count"] + amount}
        ).eq("id", row["id"]).execute()
    else:
        supabase.table("usage_logs").insert(
            {"user_id": user_id, "feature": feature, "usage_count": amount}
        ).execute()
