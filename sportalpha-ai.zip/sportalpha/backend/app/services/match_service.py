"""Fixture and prediction lookups.

Until the sports-data feed lands, matches come from a small in-process
catalogue that mirrors the frontend's demo dataset. The signatures are
the ones the real implementation will keep.
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Any

from quant_engine import MatchFeatures, ProbabilityEngine

_ENGINE = ProbabilityEngine()


def _kickoff(hours: int) -> datetime:
    return (datetime.now(timezone.utc) + timedelta(hours=hours)).replace(minute=0, second=0, microsecond=0)


DEMO_MATCHES: list[dict[str, Any]] = [
    {
        "id": "dm-001", "league": "Premier League",
        "home_team": "Arsenal", "away_team": "Brighton",
        "match_date": _kickoff(4), "status": "scheduled",
        "home_xg": 1.92, "home_xg_against": 0.98, "away_xg": 1.41, "away_xg_against": 1.36,
        "home_elo": 1884, "away_elo": 1731, "home_form": 0.74, "away_form": 0.52,
    },
    {
        "id": "dm-002", "league": "Serie A",
        "home_team": "Napoli", "away_team": "Inter",
        "match_date": _kickoff(6), "status": "scheduled",
        "home_xg": 1.58, "home_xg_against": 1.09, "away_xg": 1.64, "away_xg_against": 1.02,
        "home_elo": 1812, "away_elo": 1826, "home_form": 0.61, "away_form": 0.66,
    },
    {
        "id": "dm-003", "league": "La Liga",
        "home_team": "Girona", "away_team": "Real Madrid",
        "match_date": _kickoff(8), "status": "scheduled",
        "home_xg": 1.36, "home_xg_against": 1.61, "away_xg": 2.14, "away_xg_against": 0.94,
        "home_elo": 1698, "away_elo": 1921, "home_form": 0.48, "away_form": 0.79,
    },
]


def list_matches(limit: int = 50) -> list[dict[str, Any]]:
    return DEMO_MATCHES[:limit]


def get_match(match_id: str) -> dict[str, Any] | None:
    return next((m for m in DEMO_MATCHES if m["id"] == match_id), None)


def features_for(match: dict[str, Any], home_advantage: float = 0.15) -> MatchFeatures:
    return MatchFeatures(
        home_team=match["home_team"],
        away_team=match["away_team"],
        home_xg_for=match["home_xg"],
        home_xg_against=match["home_xg_against"],
        away_xg_for=match["away_xg"],
        away_xg_against=match["away_xg_against"],
        home_elo=match["home_elo"],
        away_elo=match["away_elo"],
        home_form=match["home_form"],
        away_form=match["away_form"],
        home_advantage=home_advantage,
    )


def predict(match: dict[str, Any]) -> dict[str, Any]:
    """Run the probability engine over one fixture."""
    output = _ENGINE.estimate(features_for(match))
    goals = output.goals.as_dict() if output.goals else {}
    return {
        "match_id": match["id"],
        "model_version": output.model_version,
        "home_probability": round(output.probabilities.home_win, 5),
        "draw_probability": round(output.probabilities.draw, 5),
        "away_probability": round(output.probabilities.away_win, 5),
        "over_15_probability": _round(goals.get("over_15")),
        "over_25_probability": _round(goals.get("over_25")),
        "over_35_probability": _round(goals.get("over_35")),
        "btts_probability": _round(goals.get("btts")),
        "confidence_score": output.confidence,
        "risk_score": output.risk,
        "generated_at": datetime.now(timezone.utc),
    }


def _round(value: float | None) -> float | None:
    return None if value is None else round(value, 5)
