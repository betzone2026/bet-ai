"""Contract tests for the quantitative engine."""
from __future__ import annotations

import math

import pytest

from quant_engine import (
    EloModel,
    EnsembleModel,
    MatchFeatures,
    PoissonModel,
    ProbabilityEngine,
    Probabilities,
    normalise,
    run_simulation,
)

STRONG_HOME = MatchFeatures(
    home_team="Arsenal", away_team="Brighton",
    home_xg_for=1.92, home_xg_against=0.98,
    away_xg_for=1.41, away_xg_against=1.36,
    home_elo=1884, away_elo=1731,
)


@pytest.mark.parametrize("model", [PoissonModel(), EloModel(), EnsembleModel()])
def test_probabilities_are_normalised(model) -> None:
    output = model.predict(STRONG_HOME)
    total = (
        output.probabilities.home_win
        + output.probabilities.draw
        + output.probabilities.away_win
    )
    assert math.isclose(total, 1.0, abs_tol=1e-6)


@pytest.mark.parametrize("model", [PoissonModel(), EloModel(), EnsembleModel()])
def test_stronger_side_is_favoured(model) -> None:
    output = model.predict(STRONG_HOME)
    assert output.probabilities.home_win > output.probabilities.away_win


def test_invalid_distribution_is_rejected() -> None:
    with pytest.raises(ValueError):
        Probabilities(0.6, 0.6, 0.6)


def test_normalise_rescales() -> None:
    p = normalise(2.0, 1.0, 1.0)
    assert math.isclose(p.home_win, 0.5)
    assert math.isclose(p.home_win + p.draw + p.away_win, 1.0)


def test_engine_rejects_unknown_model() -> None:
    with pytest.raises(KeyError):
        ProbabilityEngine(model_key="does-not-exist")


def test_poisson_goals_market_is_ordered() -> None:
    output = PoissonModel().predict(STRONG_HOME)
    assert output.goals is not None
    assert output.goals.over_15 > output.goals.over_25 > output.goals.over_35


def test_simulation_is_reproducible_and_sums_to_one() -> None:
    match = {"home_xg": 1.8, "away_xg": 1.1}
    first = run_simulation(match, simulations=20_000, seed=7)
    second = run_simulation(match, simulations=20_000, seed=7)

    assert first.as_dict() != {} and first.home_win == second.home_win
    assert math.isclose(first.home_win + first.draw + first.away_win, 1.0, abs_tol=1e-4)
    assert math.isclose(first.over_25 + first.under_25, 1.0, abs_tol=1e-4)


def test_simulation_interval_brackets_the_estimate() -> None:
    result = run_simulation({"home_xg": 1.5, "away_xg": 1.5}, simulations=20_000, seed=3)
    low, high = result.confidence_interval["home_win"]
    assert low <= result.home_win <= high


def test_simulation_rejects_zero_paths() -> None:
    with pytest.raises(ValueError):
        run_simulation({"home_xg": 1.0, "away_xg": 1.0}, simulations=0)
